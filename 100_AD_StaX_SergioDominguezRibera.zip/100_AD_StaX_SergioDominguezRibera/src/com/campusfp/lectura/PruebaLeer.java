package com.campusfp.lectura;

import java.util.List;

import com.campusfp.modelo.Item;

public class PruebaLeer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaXparse parsearLectura = new StaXparse();
		
		parsearLectura.leer("config.xml", "Pepe", "Bilbao", "10523", "Novenber 23");
		
		
	}

}
