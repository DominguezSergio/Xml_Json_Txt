package com.campusfp.lectura;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.stream.events.Attribute;

import com.campusfp.modelo.Item;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class StaXparse {
	static final String ITEM = "item";
	static final String DATE = "date";
	static final String NOMBRE = "nombre";
	static final String CIUDAD = "ciudad";
	static final String SALARIO = "salario";
	
	String cadena = "";
	
	@SuppressWarnings({ "unchecked", "null" })
	public List<Item> leer(String archivoXML, String n, String c, String s, String d) {
		System.out.println("\n*************");
		System.out.println("A�ADIENDO XML");
		System.out.println("*************");
		
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(new File(archivoXML));
			
			//prepara el archivo xml para obtener los datos
			doc.getDocumentElement().normalize();
			
			//Obtenemos el nodo padre "grupo"
			Node nodoRaiz = doc.getDocumentElement();
			
			//agregamos una nueva etiqueta al documento
			Element nuevaPersona = doc.createElement("item");//La creamos
			
			//Creamos sus etiquetas hijas(nombre, apellido y edad)
			Element nuevoNombre = doc.createElement("nombre");
			nuevoNombre.setTextContent(n);
			
			Element nuevoCiudad = doc.createElement("ciudad");
			nuevoCiudad.setTextContent(c);
			
			Element nuevoSalario = doc.createElement("salario");
			nuevoSalario.setTextContent(s);
			//Las etiquetas hijas de perona las agregamos
			nuevaPersona.appendChild(nuevoNombre);
			nuevaPersona.appendChild(nuevoNombre);
			nuevaPersona.appendChild(nuevoCiudad);
			
			//Ahora solo falta relacionar las etiquetas con nodoRaiz
			nodoRaiz.appendChild(nuevaPersona);
			
			//Ahora se transforma la estructura de datos en un archivo XML
			TransformerFactory transFactory = TransformerFactory.newInstance();
			Transformer transformer = transFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(archivoXML));
			transformer.transform(source, result);
			
			
		}catch(ParserConfigurationException parseE) {
			System.out.println(parseE.getMessage());
		}catch(SAXException saxE) {
			System.out.println(saxE.getMessage());
		}catch(IOException ioE) {
			System.out.println(ioE.getMessage());
		}catch(TransformerConfigurationException transE) {
			System.out.println(transE.getMessage());
		}catch(TransformerException transforE) {
			System.out.println(transforE.getMessage());
		}
		
		
		
		//System.out.println("a�adido");
		
		System.out.println("************");
		System.out.println("LEYENDO XML");
		System.out.println("************");
		
		List<Item> items = new ArrayList<Item>();
		try {
			
			
			
			
			XMLInputFactory factoria = XMLInputFactory.newInstance();
			InputStream entrada = new FileInputStream(archivoXML);
			XMLEventReader lector = factoria.createXMLEventReader(entrada);
			Item item = null;
			while (lector.hasNext()) {
				//Object object = (Object) lector.next();
				//System.out.println(object);
				
				XMLEvent event = lector.nextEvent();
				
				
				if (event.isStartElement()) {
                    StartElement startElement = event.asStartElement();
                    // If we have an item element, we create a new item
                    if (startElement.getName().getLocalPart().equals(ITEM)) {
                        item = new Item();
                        
                        // We read the attributes from this tag and add the date
                        // attribute to our object
                        Iterator<Attribute> attributes = startElement.getAttributes();
                        while (attributes.hasNext()) {
                            Attribute attribute = attributes.next();
                            if (attribute.getName().toString().equals(DATE)) {
                                item.setDate(attribute.getValue());
                            }

                        }
                    }

                    if (event.isStartElement()) {
                        if (event.asStartElement().getName().getLocalPart().equals(NOMBRE)) {
                            event = lector.nextEvent();

                            item.setNombre(event.asCharacters().getData());
                            continue;
                        }
                    }
                    if (event.asStartElement().getName().getLocalPart().equals(CIUDAD)) {
                        event = lector.nextEvent();
                        
                        item.setCiudad(event.asCharacters().getData());
                        continue;
                    }

                    if (event.asStartElement().getName().getLocalPart().equals(SALARIO)) {
                        event = lector.nextEvent();
                        
                        item.setSalario(event.asCharacters().getData());
                        continue;
                    }

                }
                // If we reach the end of an item element, we add it to the list
                if (event.isEndElement()) {
                    EndElement endElement = event.asEndElement();
                    if (endElement.getName().getLocalPart().equals(ITEM)) {
                        items.add(item); 
                    }
                }

            
			}
			
			for (int i = 0; i < items.size(); i++) {
				System.out.println(items.get(i));
				
			}
			
			System.out.println("\n**************");
			System.out.println("A�ADIENDO JSON");
			System.out.println("**************");
			
			String jsonString = null;
			String personas = "{peronas:[\n";
	        for(int i = 0; i<items.size(); i++) {
	        	if(i<items.size()-1) {
	        		jsonString = "{" + "'nombre':" + items.get(i).getNombre() + ",'ciudad':" + items.get(i).getCiudad() + ",'salario':" + items.get(i).getSalario() + ",'date': '" + items.get(i).getDate() + "'}";
	            	personas = personas + jsonString + ",\n";
	        	}
	        	else {
	        		jsonString = "{" + "'nombre':" + items.get(i).getNombre() + ",'ciudad':" + items.get(i).getCiudad() + ",'edad':" + items.get(i).getSalario()+ ",'date':'" + items.get(i).getDate() + "'}";
	            	personas = personas + jsonString + "\n]}";
	        	}
	        	//System.out.println("<>"+jsonString+"<>");
	        }
	        FileWriter flwriter = null;
			String ruta = ".\\archivo.json";
	        File archivo = new File(ruta);

	        try {
	        	//
	        	flwriter = new FileWriter(archivo);
				BufferedWriter bfwriter = new BufferedWriter(flwriter);
				bfwriter.write(personas);
				bfwriter.close();
	        	//
			} catch (IOException e) {
				e.printStackTrace();
			}
			
	        
	        System.out.println("\n************");
			System.out.println("LEYENDO JSON");
			System.out.println("************");
	        
			json();
			//System.out.println(cadena);
	        //
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("\n*************");
		System.out.println("A�ADIENDO TXT");
		System.out.println("*************");
		
		
		
		FileWriter flwriter = null;
		String ruta = ".\\archivo.txt";
		
        File archivo = new File(ruta);
      
        try {
        	//
        	flwriter = new FileWriter(archivo, true);
			BufferedWriter bfwriter = new BufferedWriter(flwriter);
			bfwriter.write(cadena);
			bfwriter.close();
        	//
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        System.out.println("\n***********");
        System.out.println("LEYENDO TXT");
        System.out.println("***********");
        cadena = "";
        
        try {
			FileReader f = new FileReader(ruta);
			BufferedReader b = new BufferedReader(f);
		      while((ruta = b.readLine())!=null) {
		          //System.out.println(ruta);
		          cadena = cadena + "\n" + ruta;
		          //verTexto.setText(ruta);
		      }
		      b.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        System.out.println(cadena);
		
		return null;
	}//Cierra metodo leer
	
	public void json() {
		//
		
		try {
			JsonParser parser = new JsonParser();
	        FileReader fr;
	        fr = new FileReader("archivo.json");
	        JsonElement datos = parser.parse(fr);
	        
	        cadena = "";
			//
	        if (datos.isJsonObject()) {
	            JsonObject obj = datos.getAsJsonObject();
	            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
	            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
	            while (iter.hasNext()) {
	                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
	                json2(entrada.getValue());
	            }
	        }
	        System.out.println(cadena);
	        //cadena = "";
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
	}
	
	public void json2(JsonElement datos) {
		//System.out.println("metodo json");
		if (datos.isJsonObject()) {
            JsonObject obj = datos.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                if(entrada.getKey() .equals("date")) {
                	//System.out.println("es date");
                	cadena = cadena + entrada.getKey() + ":" + entrada.getValue() + "\r" + "----\r";
                }else {
                	//System.out.println("no es date");
                	cadena = cadena + entrada.getKey() + ":" + entrada.getValue() + "\r";
                }
                
                
                json2(entrada.getValue());
            }
            //System.out.println(cadena);
            //System.out.println("vuelta");
        }
        else if(datos.isJsonArray()){
			
			JsonArray array = datos.getAsJsonArray();
			Iterator<JsonElement> iter = array.iterator();
			
			while (iter.hasNext()) {
	            JsonElement entrada = iter.next();
	            json2(entrada);
	        }
		}
		else if(datos.isJsonPrimitive()) {
		}
		else if(datos.isJsonNull()) {
		} //Cierra el if
		
	}
}//close class
